using UnityEngine;

/// <summary>
/// Ponle este script a tus enemigos. Cuando el enemigo muera,
/// llama a GetComponent<EnemyDrop>().Drop(); desde tu script de vida.
/// </summary>
public class EnemyDrop : MonoBehaviour
{
    [System.Serializable]
    public class DropItem
    {
        public GameObject prefab;                 // Objeto que se suelta (debe tener ItemPickup)
        [Range(0f, 100f)] public float chance = 50f; // Probabilidad de soltarlo (%)
        public int minAmount = 1;                 // Cantidad mínima
        public int maxAmount = 1;                 // Cantidad máxima
    }

    [Header("Lista de objetos que puede soltar")]
    public DropItem[] drops;

    [Header("Ajustes")]
    public float scatterRadius = 0.5f;   // Qué tan separados caen los objetos
    public float popForce = 3f;          // Impulso al salir (si el prefab tiene Rigidbody)

    private bool alreadyDropped = false;

    public void Drop()
    {
        if (alreadyDropped) return; // Evita soltar dos veces
        alreadyDropped = true;

        foreach (DropItem item in drops)
        {
            if (item.prefab == null) continue;

            // Tirada de probabilidad
            float roll = Random.Range(0f, 100f);
            if (roll > item.chance) continue;

            int amount = Random.Range(item.minAmount, item.maxAmount + 1);

            for (int i = 0; i < amount; i++)
            {
                Vector3 offset = Random.insideUnitCircle * scatterRadius;
                GameObject obj = Instantiate(item.prefab, transform.position + offset, Quaternion.identity);

                // Pequeño impulso hacia arriba para que "salte" (3D)
                Rigidbody rb = obj.GetComponent<Rigidbody>();
                if (rb != null)
                    rb.AddForce(Vector3.up * popForce, ForceMode.Impulse);

                // Pequeño impulso (2D)
                Rigidbody2D rb2d = obj.GetComponent<Rigidbody2D>();
                if (rb2d != null)
                    rb2d.AddForce(Random.insideUnitCircle * popForce, ForceMode2D.Impulse);
            }
        }
    }
}