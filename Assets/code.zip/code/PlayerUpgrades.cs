using UnityEngine;

/// <summary>
/// Ponle este script al jugador. Según la cantidad de objetos recogidos,
/// el equipo sube de nivel: más daño y más vida máxima.
/// </summary>
public class PlayerUpgrades : MonoBehaviour
{
    [Header("Objetos recogidos")]
    public int itemsCollected = 0;

    [Header("Mejora de equipo")]
    public int itemsPerLevel = 5;     // Objetos necesarios para subir un nivel
    public int maxEquipmentLevel = 10; // Nivel máximo del equipo
    public int equipmentLevel = 0;     // Nivel actual (se calcula solo)

    [Header("Daño")]
    public float baseDamage = 10f;
    public float damagePerLevel = 3f;  // Daño extra por cada nivel

    [Header("Vida")]
    public float baseMaxHealth = 100f;
    public float healthPerLevel = 20f; // Vida máxima extra por cada nivel
    public float currentHealth;

    // Valores finales (úsalos desde tus otros scripts)
    public float Damage => baseDamage + damagePerLevel * equipmentLevel;
    public float MaxHealth => baseMaxHealth + healthPerLevel * equipmentLevel;

    // Eventos por si quieres actualizar la UI
    public event System.Action<int> OnItemsChanged;
    public event System.Action<int> OnEquipmentLevelUp;
    public event System.Action<float, float> OnHealthChanged;

    private void Start()
    {
        currentHealth = MaxHealth;
        RecalculateLevel(false);
        OnHealthChanged?.Invoke(currentHealth, MaxHealth);
    }

    public void AddItems(int amount)
    {
        itemsCollected += amount;
        OnItemsChanged?.Invoke(itemsCollected);
        RecalculateLevel(true);
    }

    private void RecalculateLevel(bool healOnLevelUp)
    {
        int newLevel = Mathf.Min(itemsCollected / itemsPerLevel, maxEquipmentLevel);

        if (newLevel > equipmentLevel)
        {
            float oldMax = MaxHealth;
            equipmentLevel = newLevel;

            // Al subir de nivel, sumar la vida extra a la vida actual
            if (healOnLevelUp)
                currentHealth += MaxHealth - oldMax;

            OnEquipmentLevelUp?.Invoke(equipmentLevel);
            OnHealthChanged?.Invoke(currentHealth, MaxHealth);
            Debug.Log($"¡Equipo nivel {equipmentLevel}! Daño: {Damage} | Vida máx: {MaxHealth}");
        }
    }

    public void TakeDamage(float amount)
    {
        currentHealth = Mathf.Max(0f, currentHealth - amount);
        OnHealthChanged?.Invoke(currentHealth, MaxHealth);

        if (currentHealth <= 0f)
            Die();
    }

    public void Heal(float amount)
    {
        currentHealth = Mathf.Min(MaxHealth, currentHealth + amount);
        OnHealthChanged?.Invoke(currentHealth, MaxHealth);
    }

    private void Die()
    {
        Debug.Log("El jugador murió");
        // Aquí pon tu lógica de muerte (reiniciar nivel, pantalla de game over, etc.)
    }
}