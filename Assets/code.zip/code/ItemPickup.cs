using UnityEngine;

/// <summary>
/// Ponle este script al prefab del objeto que sueltan los enemigos.
/// El prefab necesita un Collider con "Is Trigger" activado.
/// El jugador debe tener el tag "Player" y el script PlayerUpgrades.
/// </summary>
public class ItemPickup : MonoBehaviour
{
    public int value = 1; // Cuántos "objetos" cuenta al recogerlo

    // Para juegos 3D
    private void OnTriggerEnter(Collider other)
    {
        TryPickup(other.gameObject);
    }

    // Para juegos 2D
    private void OnTriggerEnter2D(Collider2D other)
    {
        TryPickup(other.gameObject);
    }

    private void TryPickup(GameObject other)
    {
        if (!other.CompareTag("Player")) return;

        PlayerUpgrades upgrades = other.GetComponent<PlayerUpgrades>();
        if (upgrades == null) return;

        upgrades.AddItems(value);
        Destroy(gameObject);
    }
}